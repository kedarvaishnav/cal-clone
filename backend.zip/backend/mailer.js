const nodemailer = require('nodemailer');
require('dotenv').config();

const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS,
  },
});

async function sendBookingConfirmation({ bookerName, bookerEmail, eventTitle, startTime, endTime, hostEmail }) {
  const dateStr = new Date(startTime).toLocaleString('en-IN', {
    timeZone: 'Asia/Kolkata',
    dateStyle: 'full',
    timeStyle: 'short'
  });
  const endStr = new Date(endTime).toLocaleString('en-IN', {
    timeZone: 'Asia/Kolkata',
    timeStyle: 'short'
  });

  // Email to BOOKER
  await transporter.sendMail({
    from: `"Cal Clone" <${process.env.EMAIL_USER}>`,
    to: bookerEmail,
    subject: `Booking Confirmed: ${eventTitle}`,
    html: `
      <div style="font-family: Inter, sans-serif; max-width: 500px; margin: 0 auto; padding: 32px; border: 1px solid #e5e7eb; border-radius: 12px;">
        <div style="background: #6366f1; color: white; padding: 20px; border-radius: 8px; text-align: center; margin-bottom: 24px;">
          <h1 style="margin:0; font-size: 22px;">✅ Booking Confirmed!</h1>
        </div>
        <p style="color: #374151;">Hi <strong>${bookerName}</strong>,</p>
        <p style="color: #374151;">Your meeting has been successfully scheduled.</p>
        <div style="background: #f9fafb; padding: 16px; border-radius: 8px; margin: 20px 0;">
          <p style="margin: 4px 0;"><strong>📅 Event:</strong> ${eventTitle}</p>
          <p style="margin: 4px 0;"><strong>🕐 Time:</strong> ${dateStr} – ${endStr} IST</p>
        </div>
        <p style="color: #6b7280; font-size: 13px;">If you need to cancel, please contact us.</p>
      </div>
    `
  });

  // Email to HOST (you)
  await transporter.sendMail({
    from: `"Cal Clone" <${process.env.EMAIL_USER}>`,
    to: hostEmail,
    subject: `New Booking: ${eventTitle} with ${bookerName}`,
    html: `
      <div style="font-family: Inter, sans-serif; max-width: 500px; margin: 0 auto; padding: 32px; border: 1px solid #e5e7eb; border-radius: 12px;">
        <div style="background: #111827; color: white; padding: 20px; border-radius: 8px; text-align: center; margin-bottom: 24px;">
          <h1 style="margin:0; font-size: 22px;">📬 New Meeting Booked!</h1>
        </div>
        <p style="color: #374151;">You have a new booking:</p>
        <div style="background: #f9fafb; padding: 16px; border-radius: 8px; margin: 20px 0;">
          <p style="margin: 4px 0;"><strong>👤 Name:</strong> ${bookerName}</p>
          <p style="margin: 4px 0;"><strong>📧 Email:</strong> ${bookerEmail}</p>
          <p style="margin: 4px 0;"><strong>📅 Event:</strong> ${eventTitle}</p>
          <p style="margin: 4px 0;"><strong>🕐 Time:</strong> ${dateStr} – ${endStr} IST</p>
        </div>
      </div>
    `
  });

  console.log(`Emails sent to ${bookerEmail} and ${hostEmail}`);
}

module.exports = { sendBookingConfirmation };